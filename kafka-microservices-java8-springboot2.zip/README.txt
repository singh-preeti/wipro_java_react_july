Kafka Microservices Example (Java 8 + Spring Boot 2)
--------------------------------------------------

Projects:
- order-service (producer)  -> port 8081, POST /orders  (sends message to topic 'order-events')
- inventory-service (consumer) -> port 8082, listens to topic 'order-events'

Prerequisites:
- Java 8 JDK
- Maven
- Apache Kafka running locally (bootstrap server: localhost:9092)
  - Start Zookeeper (if using Zookeeper mode)
  - Start Kafka broker
  - Create topic: bin/kafka-topics.sh --create --topic order-events --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1

How to run:
1. Start Kafka broker (and Zookeeper if needed).
2. From project root, build each service:
   cd order-service
   mvn clean package
   java -jar target/order-service-1.0.0.jar

   cd ../inventory-service
   mvn clean package
   java -jar target/inventory-service-1.0.0.jar

3. Send a test order:
   curl -X POST http://localhost:8081/orders -H "Content-Type: application/json" -d "Order123"

You should see Inventory Service logs printing the received message.

Notes:
- These example projects are minimal to show Kafka communication.
- For production-ready apps add error handling, DTOs, JSON (de)serialization, schema registry (optional), monitoring, security, and retries.
