import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Main {
    public static void main(String[] args) {
        SessionFactory factory = new Configuration().configure().addAnnotatedClass(Employee.class).buildSessionFactory();

        Employee emp = new Employee("Amit", "IT", 55000);

        Session session = factory.openSession();
        session.beginTransaction();
        session.save(emp);
        session.getTransaction().commit();
        System.out.println("Employee saved: " + emp);

        session = factory.openSession();
        Employee fetched = session.get(Employee.class, emp.getId());
        System.out.println("Fetched: " + fetched);

        session.beginTransaction();
        fetched.setSalary(60000);
        session.update(fetched);
        session.getTransaction().commit();
        System.out.println("Updated Salary: " + fetched.getSalary());

        session.beginTransaction();
        session.delete(fetched);
        session.getTransaction().commit();
        System.out.println("Employee deleted");

        session.close();
        factory.close();
    }
}
