package com.ecommerce;

public abstract class Payment {
    public abstract void pay(double amount);
}
