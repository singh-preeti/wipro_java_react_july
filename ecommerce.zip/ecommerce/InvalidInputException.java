package com.ecommerce;

public class InvalidInputException extends Exception {
    public InvalidInputException(String message) {
        super(message);
    }
}
