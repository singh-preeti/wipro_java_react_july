package com.ecommerce;

public class Main {
    public static void main(String[] args) {
        EcommerceService service = new EcommerceService();
        service.placeOrder();
    }
}
